VEREXAHQ - FORMS & TEMPLATES UI

UI-only redesign for the Forms section.

Flow:
Form Templates -> Preview
Form Templates -> Edit -> Drag-and-drop builder
Form Templates -> New Form -> Builder

The separate Form Overview screen is intentionally removed.

Included:
- Form template library
- Search/status filtering
- Template thumbnails
- Client preview
- Drag-and-drop field builder
- Field palette and field reordering
- Field properties panel
- New-form visual flow
- Responsive layout
- VerexaHQ visual styling

Not included:
- Database schema
- API routes
- Backend logic
- Business rules
- Permissions
- Persistence

Upload:
Copy verexa-forms-templates.tsx into the existing Forms/Templates route.
Adapt only the surrounding route/layout imports required by the project.

Important:
The sample template data is local to this UI mockup. It does not alter
your existing database or backend. Actual save/load behavior should only
be connected after backend behavior is explicitly defined.
