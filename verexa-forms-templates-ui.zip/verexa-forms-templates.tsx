"use client";

import { useMemo, useState } from "react";

type Template = {
  id: string;
  name: string;
  type: string;
  status: "Active" | "Draft";
  sections: number;
  fields: number;
  edited: string;
};

type Field = { id: number; label: string; kind: string };

const templates: Template[] = [
  { id: "individual", name: "2025 Individual Tax Organizer", type: "Tax organizer", status: "Active", sections: 18, fields: 64, edited: "2 days ago" },
  { id: "business", name: "Business Tax Organizer", type: "Tax organizer", status: "Active", sections: 12, fields: 47, edited: "6 days ago" },
  { id: "intake", name: "New Client Intake", type: "Client intake", status: "Draft", sections: 7, fields: 29, edited: "Yesterday" },
];

const palette = [
  ["TEXT", ["Short answer", "Long answer", "Number", "Currency", "Date", "Email"]],
  ["CHOICES", ["Dropdown", "Radio buttons", "Checkbox"]],
  ["UPLOADS", ["Document upload", "Image upload"]],
  ["LAYOUT", ["Section", "Divider", "Information block"]],
];

const starterFields: Field[] = [
  { id: 1, label: "Full legal name", kind: "Short answer" },
  { id: 2, label: "Filing status", kind: "Dropdown" },
  { id: 3, label: "W-2 information", kind: "Document upload" },
];

export default function FormsTemplates() {
  const [view, setView] = useState<"library" | "builder" | "preview">("library");
  const [selected, setSelected] = useState<Template | null>(null);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("All statuses");
  const [fields, setFields] = useState<Field[]>(starterFields);
  const [dragged, setDragged] = useState<string | number | null>(null);
  const [newForm, setNewForm] = useState(false);
  const [newName, setNewName] = useState("");

  const filtered = useMemo(
    () =>
      templates.filter(
        (t) =>
          (!query || t.name.toLowerCase().includes(query.toLowerCase())) &&
          (status === "All statuses" || t.status === status)
      ),
    [query, status]
  );

  function editTemplate(t: Template) {
    setSelected(t);
    setFields(starterFields.map((f) => ({ ...f })));
    setView("builder");
  }

  function addField(kind: string) {
    setFields((current) => [
      ...current,
      {
        id: Date.now(),
        label: kind === "Short answer" ? "New question" : kind,
        kind,
      },
    ]);
  }

  function moveField(from: number, to: number) {
    if (from === to) return;
    setFields((current) => {
      const next = [...current];
      const [item] = next.splice(from, 1);
      next.splice(to, 0, item);
      return next;
    });
  }

  if (view === "builder" && selected) {
    return (
      <div className="vx-screen">
        <style>{styles}</style>
        <header className="vx-top">
          <button className="vx-btn" onClick={() => setView("library")}>
            ← Form Templates
          </button>
          <div className="vx-top-title">
            <span>FORM BUILDER</span>
            <b>{selected.name}</b>
          </div>
          <div className="vx-actions">
            <button className="vx-btn" onClick={() => setView("preview")}>
              Preview
            </button>
            <button className="vx-btn vx-primary" onClick={() => setView("library")}>
              Save template
            </button>
          </div>
        </header>

        <div className="vx-builder">
          <aside className="vx-palette">
            <b>Form elements</b>
            <small>Drag onto the canvas. Double-click to add.</small>
            {palette.map(([group, items]) => (
              <div key={group}>
                <h5>{group}</h5>
                {(items as string[]).map((item) => (
                  <button
                    key={item}
                    draggable
                    onDragStart={() => setDragged(item)}
                    onDragEnd={() => setDragged(null)}
                    onDoubleClick={() => addField(item)}
                    className="vx-drag"
                  >
                    {item}
                  </button>
                ))}
              </div>
            ))}
          </aside>

          <main className="vx-canvas">
            <div className="vx-paper">
              <div className="vx-formhead">
                <span>VEREXAHQ • TAX ORGANIZER</span>
                <h1>{selected.name}</h1>
                <p>Build the client-facing form by arranging sections and fields.</p>
              </div>

              <div className="vx-section-label">1 · PERSONAL INFORMATION</div>

              {fields.map((field, index) => (
                <div
                  key={field.id}
                  draggable
                  onDragStart={() => setDragged(field.id)}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={() => {
                    const from = fields.findIndex((f) => f.id === dragged);
                    if (from >= 0) moveField(from, index);
                    setDragged(null);
                  }}
                  className={"vx-field " + (dragged === field.id ? "vx-selected" : "")}
                >
                  <div className="vx-field-label">
                    ☰ &nbsp; {field.label}
                    <em>{field.kind}</em>
                  </div>
                  {field.kind === "Document upload" ? (
                    <div className="vx-upload">Document upload area</div>
                  ) : (
                    <div className="vx-input" />
                  )}
                </div>
              ))}

              <div
                className="vx-dropzone"
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => {
                  if (typeof dragged === "string") addField(dragged);
                  setDragged(null);
                }}
              >
                ＋ Drop a form element here
              </div>

              <div className="vx-section-label vx-section-two">2 · INCOME</div>
              <div className="vx-dropzone">＋ Drop field here</div>
            </div>
          </main>

          <aside className="vx-properties">
            <b>Field properties</b>
            <small>Select and arrange fields visually.</small>
            <label>
              Label
              <input value={fields.find((f) => f.id === dragged)?.label || ""} readOnly />
            </label>
            <label>
              Description
              <textarea placeholder="Optional helper text" />
            </label>
            <label>
              Appearance
              <select>
                <option>Standard</option>
                <option>Compact</option>
              </select>
            </label>
            <div className="vx-note">
              Required status, valid option values, conditional rules, and persistence are intentionally not decided in this UI-only design.
            </div>
          </aside>
        </div>
      </div>
    );
  }

  if (view === "preview" && selected) {
    return (
      <div className="vx-page">
        <style>{styles}</style>
        <div className="vx-preview-head">
          <div>
            <button className="vx-link" onClick={() => setView("builder")}>
              ← Back to builder
            </button>
            <span className="vx-eyebrow">CLIENT PREVIEW</span>
            <h1>{selected.name}</h1>
            <p>See the experience a client would encounter.</p>
          </div>
          <button className="vx-btn vx-primary" onClick={() => setView("builder")}>
            Edit form
          </button>
        </div>

        <div className="vx-client-card">
          <div className="vx-client-brand">VEREXAHQ</div>
          <div className="vx-client-row">
            <h2>{selected.name}</h2>
            <span>Step 1</span>
          </div>
          <div className="vx-progress"><i /></div>
          <h3>Personal Information</h3>
          <p>Let's start with some basic information.</p>
          <label>Full legal name<div className="vx-input" /></label>
          <label>Filing status<div className="vx-input" /></label>
          <div className="vx-client-actions">
            <button className="vx-btn">Save &amp; exit</button>
            <button className="vx-btn vx-primary">Continue →</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="vx-page">
      <style>{styles}</style>

      <div className="vx-heading">
        <div>
          <span className="vx-eyebrow">FORMS</span>
          <h1>Form Templates</h1>
          <p>Build, organize, preview and reuse the forms your clients complete.</p>
        </div>
        <button className="vx-btn vx-primary" onClick={() => setNewForm(true)}>
          ＋ New form
        </button>
      </div>

      <div className="vx-toolbar">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="⌕  Search form templates…"
        />
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option>All statuses</option>
          <option>Active</option>
          <option>Draft</option>
        </select>
      </div>

      <div className="vx-grid">
        {filtered.map((t) => (
          <article className="vx-card" key={t.id}>
            <button
              className="vx-thumbnail"
              onClick={() => {
                setSelected(t);
                setView("preview");
              }}
            >
              <div className="vx-mini-paper">
                <span>VEREXAHQ</span>
                <b>{t.name}</b>
                <small>PERSONAL INFORMATION</small>
                <i /><i /><i className="short" />
              </div>
            </button>

            <div className="vx-card-body">
              <h3>{t.name}</h3>
              <p>{t.type}</p>
              <div>
                <span className="vx-pill">{t.status}</span>
                <span className="vx-pill">{t.sections} sections</span>
                <span className="vx-pill">{t.fields} fields</span>
              </div>
            </div>

            <div className="vx-card-footer">
              <small>Edited {t.edited}</small>
              <div>
                <button
                  className="vx-btn"
                  onClick={() => {
                    setSelected(t);
                    setView("preview");
                  }}
                >
                  Preview
                </button>
                <button className="vx-btn" onClick={() => editTemplate(t)}>
                  Edit
                </button>
              </div>
            </div>
          </article>
        ))}

        <button className="vx-create" onClick={() => setNewForm(true)}>
          <b>＋</b>
          <strong>Create a new form</strong>
          <span>Start blank or choose a starting point.</span>
        </button>
      </div>

      {newForm && (
        <div className="vx-overlay">
          <div className="vx-modal">
            <div className="vx-modal-head">
              <div>
                <span className="vx-eyebrow">FORMS</span>
                <h2>Create a new form</h2>
                <p>Choose how you want to start building.</p>
              </div>
              <button onClick={() => setNewForm(false)}>×</button>
            </div>

            <input
              className="vx-name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Form name"
            />

            <div className="vx-choices">
              {["Start blank", "Start from a template", "Import a form"].map((choice) => (
                <button
                  key={choice}
                  onClick={() => {
                    const t: Template = {
                      id: "new",
                      name: newName || "New Form",
                      type: "Form template",
                      status: "Draft",
                      sections: 1,
                      fields: 0,
                      edited: "Just now",
                    };
                    setSelected(t);
                    setNewForm(false);
                    setView("builder");
                  }}
                >
                  <b>{choice === "Start blank" ? "＋" : choice === "Import a form" ? "↗" : "▣"}</b>
                  <strong>{choice}</strong>
                  <span>Open the visual builder.</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = `
:root{--teal:#10a9a7;--green:#79cf48;--bg:#f4f8f7;--line:#dce7e3;--text:#12231f;--muted:#687a75}
*{box-sizing:border-box}
body{margin:0}
button,input,textarea,select{font:inherit}
.vx-page{min-height:100vh;background:var(--bg);color:var(--text);padding:32px;font-family:Inter,system-ui,sans-serif}
.vx-screen{height:100vh;background:var(--bg);color:var(--text);font-family:Inter,system-ui,sans-serif}
.vx-top{height:64px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;padding:0 20px}
.vx-top-title span,.vx-eyebrow{display:block;font-size:9px;letter-spacing:.14em;color:#108a64;font-weight:900}
.vx-top-title b{font-size:13px}.vx-actions{display:flex;gap:8px}
.vx-btn{border:1px solid var(--line);background:#fff;border-radius:9px;padding:9px 12px;font-size:10px;font-weight:800;cursor:pointer}
.vx-primary{border-color:transparent;background:linear-gradient(135deg,var(--teal),#22b6a3);color:#fff}
.vx-heading{display:flex;justify-content:space-between;align-items:end;gap:20px;max-width:1450px;margin:auto}
.vx-heading h1,.vx-preview-head h1{font-size:30px;letter-spacing:-.04em;margin:5px 0}
.vx-heading p,.vx-preview-head p{font-size:11px;color:var(--muted);margin:0}
.vx-toolbar{max-width:1450px;margin:24px auto 0;display:flex;gap:8px}
.vx-toolbar input{width:320px;max-width:100%;padding:11px 13px;border:1px solid var(--line);border-radius:10px;background:#fff;font-size:11px}
.vx-toolbar select{padding:11px;border:1px solid var(--line);border-radius:10px;background:#fff;font-size:11px}
.vx-grid{max-width:1450px;margin:18px auto;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}
.vx-card{background:#fff;border:1px solid var(--line);border-radius:16px;overflow:hidden;display:flex;flex-direction:column;min-height:355px}
.vx-thumbnail{height:175px;border:0;border-bottom:1px solid var(--line);background:linear-gradient(#eef7f5,#f8fbfa);padding:16px;cursor:pointer}
.vx-mini-paper{height:100%;background:#fff;border:1px solid var(--line);border-radius:9px;box-shadow:0 8px 20px #061c2b0b;padding:13px;text-align:left;overflow:hidden}
.vx-mini-paper span{font-size:7px;color:var(--teal);font-weight:900;letter-spacing:.12em}
.vx-mini-paper b{display:block;font-size:13px;margin:5px 0 12px}
.vx-mini-paper small{font-size:7px;color:var(--muted);font-weight:900}
.vx-mini-paper i{display:block;height:22px;border:1px solid var(--line);border-radius:5px;margin-top:7px}
.vx-mini-paper i.short{width:65%}.vx-card-body{padding:16px;flex:1}
.vx-card-body h3{font-size:13px;margin:0}.vx-card-body p{font-size:10px;color:var(--muted);margin:4px 0 10px}
.vx-pill{display:inline-block;background:#edf4f2;color:#51655f;border-radius:999px;padding:5px 8px;font-size:8px;font-weight:800;margin-right:5px}
.vx-card-footer{border-top:1px solid var(--line);padding:12px 16px;display:flex;justify-content:space-between;align-items:center;gap:10px}
.vx-card-footer small{font-size:9px;color:var(--muted)}.vx-card-footer .vx-btn{padding:7px 9px;margin-left:5px}
.vx-create{min-height:355px;border:1.5px dashed #a8cbc3;border-radius:16px;background:linear-gradient(#f6fcfa,#fff);cursor:pointer}
.vx-create b{display:grid;place-items:center;width:44px;height:44px;margin:auto;border-radius:12px;background:#e8f8f4;color:#0a9582;font-size:25px}
.vx-create strong{display:block;margin-top:12px;font-size:13px}.vx-create span{display:block;margin-top:4px;font-size:10px;color:var(--muted)}
.vx-overlay{position:fixed;inset:0;background:#061c2b40;backdrop-filter:blur(4px);display:grid;place-items:center;padding:20px;z-index:50}
.vx-modal{width:min(850px,100%);background:#fff;border:1px solid var(--line);border-radius:18px;padding:25px;box-shadow:0 30px 80px #061c2b25}
.vx-modal-head{display:flex;justify-content:space-between}.vx-modal-head h2{font-size:23px;margin:4px 0}
.vx-modal-head p{font-size:10px;color:var(--muted);margin:0}.vx-modal-head button{border:0;background:none;font-size:22px}
.vx-name{width:100%;padding:11px;border:1px solid var(--line);border-radius:9px;margin-top:18px}
.vx-choices{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:14px}
.vx-choices button{text-align:left;border:1px solid var(--line);border-radius:13px;background:#fff;padding:18px;cursor:pointer}
.vx-choices button:hover{border-color:#8bcfc0}.vx-choices b{display:grid;place-items:center;width:40px;height:40px;background:#e8f8f4;color:#0a9582;border-radius:10px;font-size:20px}
.vx-choices strong{display:block;font-size:11px;margin-top:10px}.vx-choices span{display:block;font-size:9px;color:var(--muted);margin-top:3px}
.vx-builder{height:calc(100vh - 64px);display:grid;grid-template-columns:230px minmax(0,1fr) 280px}
.vx-palette,.vx-properties{background:#fff;overflow:auto;padding:16px}.vx-palette{border-right:1px solid var(--line)}.vx-properties{border-left:1px solid var(--line)}
.vx-palette b,.vx-properties b{font-size:12px}.vx-palette small,.vx-properties small{display:block;color:var(--muted);font-size:9px;margin-top:4px}
.vx-palette h5{font-size:8px;letter-spacing:.12em;color:var(--muted);margin:17px 0 6px}
.vx-drag{display:block;width:100%;text-align:left;padding:10px;border:1px solid var(--line);border-radius:9px;background:#fff;font-size:10px;margin:6px 0;cursor:grab}
.vx-canvas{overflow:auto;background-image:radial-gradient(#d5e1de 1px,transparent 1px);background-size:20px 20px;padding:25px}
.vx-paper{max-width:760px;min-height:780px;margin:auto;background:#fff;border:1px solid var(--line);border-radius:15px;box-shadow:0 15px 40px #061c2b0e;padding:28px}
.vx-formhead{border-bottom:1px solid var(--line);padding-bottom:17px;margin-bottom:18px}.vx-formhead span{font-size:8px;color:#108a64;font-weight:900;letter-spacing:.14em}
.vx-formhead h1{font-size:20px;margin:5px 0}.vx-formhead p{font-size:10px;color:var(--muted);margin:0}
.vx-section-label{font-size:8px;letter-spacing:.12em;color:#108a64;font-weight:900}.vx-field{padding:12px;border:1.5px dashed #a9d3c9;border-radius:11px;margin:9px 0;background:#fbfefd;cursor:move}
.vx-field.vx-selected{border-style:solid;border-color:var(--teal);box-shadow:0 0 0 3px #10a9a714}.vx-field-label{font-size:9px;font-weight:900}
.vx-field-label em{float:right;color:var(--muted);font-size:8px;font-style:normal;font-weight:500}.vx-input{height:34px;border:1px solid var(--line);border-radius:7px;margin-top:7px}
.vx-upload{height:48px;border:1px dashed #b9d6ce;border-radius:7px;margin-top:7px;display:grid;place-items:center;font-size:9px;color:var(--muted)}
.vx-dropzone{padding:18px;text-align:center;border:1.5px dashed #a9d3c9;border-radius:11px;color:var(--muted);font-size:9px;margin-top:10px}
.vx-section-two{margin-top:22px}.vx-properties label{display:block;font-size:8px;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);font-weight:900;margin-top:18px}
.vx-properties input,.vx-properties textarea,.vx-properties select{width:100%;margin-top:6px;border:1px solid var(--line);border-radius:8px;padding:9px;font-size:10px}
.vx-note{margin-top:18px;padding:11px;border-radius:9px;background:var(--bg);font-size:9px;color:var(--muted)}
.vx-preview-head{max-width:1200px;margin:auto;display:flex;justify-content:space-between;align-items:end;gap:15px}
.vx-link{border:0;background:none;color:var(--muted);font-size:10px;padding:0}.vx-client-card{max-width:820px;margin:28px auto;background:#fff;border:1px solid var(--line);border-radius:16px;box-shadow:0 18px 50px #061c2b12;padding:30px}
.vx-client-brand{font-size:9px;color:#108a64;font-weight:900;letter-spacing:.15em}.vx-client-row{display:flex;justify-content:space-between;align-items:center}
.vx-client-row h2{font-size:20px}.vx-client-row span{font-size:8px;background:var(--bg);padding:5px 8px;border-radius:999px}
.vx-progress{height:6px;background:#e7efec;border-radius:9px}.vx-progress i{display:block;width:18%;height:100%;background:linear-gradient(90deg,var(--teal),var(--green));border-radius:9px}
.vx-client-card h3{font-size:15px;margin-top:26px}.vx-client-card p{font-size:10px;color:var(--muted)}.vx-client-card label{display:block;font-size:9px;font-weight:900;margin-top:18px}
.vx-client-actions{display:flex;justify-content:space-between;margin-top:28px}
@media(max-width:1000px){.vx-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.vx-builder{grid-template-columns:220px minmax(0,1fr)}.vx-properties{display:none}}
@media(max-width:700px){.vx-page{padding:20px}.vx-heading{align-items:start;flex-direction:column}.vx-grid{grid-template-columns:1fr}.vx-toolbar{flex-direction:column}.vx-toolbar input{width:100%}.vx-choices{grid-template-columns:1fr}.vx-builder{grid-template-columns:1fr}.vx-palette{display:none}.vx-top-title{display:none}.vx-paper{padding:18px}.vx-canvas{padding:12px}.vx-client-card{padding:20px}.vx-preview-head{align-items:start;flex-direction:column}}
