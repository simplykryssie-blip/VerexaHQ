# VerexaHQ Brand Center — Manual Install

This package contains the two frontend files needed to activate the new Branding tab.

## Files included

1. `components/BrandCenter.tsx`
2. `app/(app)/settings/page.tsx`

The Supabase backend was already created, including:

- `workspace_brand_profiles`
- `workspace-brand-assets`
- workspace RLS policies
- template-copy function

## Install with GitHub in a browser

1. Download and unzip this package.
2. Open your `VerexaHQ` repository on GitHub.
3. Open the `components` folder.
4. Click **Add file → Create new file**.
5. Name the file `BrandCenter.tsx`.
6. Open the downloaded `components/BrandCenter.tsx`, copy all content, and paste it into GitHub.
7. Click **Commit changes**.

Then:

8. Open `app/(app)/settings/page.tsx` in GitHub.
9. Click the pencil icon to edit.
10. Delete the current contents.
11. Paste the entire contents of the downloaded replacement file.
12. Click **Commit changes**.

Vercel should automatically deploy after the commits.

## Install with GitHub Desktop or VS Code

1. Unzip this package.
2. Open your local VerexaHQ project.
3. Copy `components/BrandCenter.tsx` into the project's `components` folder.
4. Replace the existing `app/(app)/settings/page.tsx` with the included file.
5. Commit with the message: `Add workspace Brand Center`
6. Push to GitHub.
7. Let Vercel redeploy.

## After deployment

Sign in to VerexaHQ and open:

**Settings → Branding**

You should see:

- logo upload
- office colors
- legal name and DBA
- contact details
- font settings
- document footer
- disclaimer
- watermark
- live document preview

## Important note about logo display

The current component uses Supabase `getPublicUrl`. If your storage bucket is private, the saved upload may need a signed-URL adjustment. The upload itself will still work if your workspace storage policy allows it.
