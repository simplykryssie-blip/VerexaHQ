"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { ImagePlus, Save, Upload } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useWorkspace } from "@/components/WorkspaceProvider";

type BrandProfile = {
  legal_name: string;
  dba_name: string;
  logo_url: string;
  alternate_logo_url: string;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  heading_font: string;
  body_font: string;
  logo_alignment: "left" | "center" | "right";
  logo_width: number;
  phone: string;
  email: string;
  website: string;
  address: string;
  footer: string;
  disclaimer: string;
  watermark: string;
};

const EMPTY_PROFILE: BrandProfile = {
  legal_name: "",
  dba_name: "",
  logo_url: "",
  alternate_logo_url: "",
  primary_color: "#108A64",
  secondary_color: "#0F2F2A",
  accent_color: "#D6A84B",
  heading_font: "Georgia",
  body_font: "Arial",
  logo_alignment: "left",
  logo_width: 180,
  phone: "",
  email: "",
  website: "",
  address: "",
  footer: "",
  disclaimer: "",
  watermark: "",
};

export default function BrandCenter() {
  const { activeWorkspaceId, activeWorkspace } = useWorkspace();

  const [profile, setProfile] = useState<BrandProfile>(EMPTY_PROFILE);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadProfile = useCallback(async () => {
    if (!activeWorkspaceId) return;

    setError(null);

    const { data, error: loadError } = await supabase
      .from("workspace_brand_profiles")
      .select("*")
      .eq("workspace_id", activeWorkspaceId)
      .maybeSingle();

    if (loadError) {
      setError(loadError.message);
      return;
    }

    setProfile({
      ...EMPTY_PROFILE,
      legal_name: activeWorkspace?.name || "",
      ...(data || {}),
    });
  }, [activeWorkspaceId, activeWorkspace?.name]);

  useEffect(() => {
    void loadProfile();
  }, [loadProfile]);

  function updateField<K extends keyof BrandProfile>(
    key: K,
    value: BrandProfile[K],
  ) {
    setProfile((current) => ({ ...current, [key]: value }));
  }

  async function uploadLogo(file?: File) {
    if (!file || !activeWorkspaceId) return;

    setUploading(true);
    setError(null);
    setMessage(null);

    const extension = file.name.split(".").pop()?.toLowerCase() || "png";
    const path = `${activeWorkspaceId}/logo-${Date.now()}.${extension}`;

    const { error: uploadError } = await supabase.storage
      .from("workspace-brand-assets")
      .upload(path, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (uploadError) {
      setUploading(false);
      setError(uploadError.message);
      return;
    }

    const { data } = supabase.storage
      .from("workspace-brand-assets")
      .getPublicUrl(path);

    updateField("logo_url", data.publicUrl);
    setUploading(false);
    setMessage("Logo uploaded. Click Save brand kit to store the change.");
  }

  async function saveProfile() {
    if (!activeWorkspaceId) return;

    setSaving(true);
    setError(null);
    setMessage(null);

    const { error: saveError } = await supabase
      .from("workspace_brand_profiles")
      .upsert(
        {
          workspace_id: activeWorkspaceId,
          ...profile,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "workspace_id" },
      );

    setSaving(false);

    if (saveError) {
      setError(saveError.message);
      return;
    }

    setMessage(
      "Brand kit saved. New documents and workspace templates can use this branding.",
    );
  }

  const displayName =
    profile.dba_name ||
    profile.legal_name ||
    activeWorkspace?.name ||
    "Your firm";

  const contactLine = useMemo(
    () =>
      [profile.phone, profile.email, profile.website]
        .filter(Boolean)
        .join(" · "),
    [profile.phone, profile.email, profile.website],
  );

  return (
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_430px]">
      <section className="rounded-2xl border border-line bg-white p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="font-bold text-ink">Office Brand Kit</h2>
            <p className="mt-1 max-w-2xl text-sm text-muted">
              Set the branding used on documents, forms, invoices, and client
              communications for this workspace.
            </p>
          </div>

          <button
            type="button"
            onClick={saveProfile}
            disabled={saving || !activeWorkspaceId}
            className="flex items-center gap-2 rounded-xl bg-[#108A64] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#0d7555] disabled:cursor-not-allowed disabled:opacity-60"
          >
            <Save size={16} />
            {saving ? "Saving…" : "Save brand kit"}
          </button>
        </div>

        {message && (
          <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
            {message}
          </div>
        )}

        {error && (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">
            {error}
          </div>
        )}

        <div className="mt-6 grid gap-5 sm:grid-cols-2">
          <Field label="Legal business name">
            <input
              value={profile.legal_name}
              onChange={(event) =>
                updateField("legal_name", event.target.value)
              }
              className="brand-input"
              placeholder="Verexa Financial Services LLC"
            />
          </Field>

          <Field label="DBA / display name">
            <input
              value={profile.dba_name}
              onChange={(event) => updateField("dba_name", event.target.value)}
              className="brand-input"
              placeholder="Verexa Financial"
            />
          </Field>

          <Field label="Office logo">
            <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-line p-4 text-sm font-semibold text-[#108A64] transition hover:bg-emerald-50">
              <Upload size={17} />
              {uploading ? "Uploading…" : "Upload logo"}
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp,image/svg+xml"
                className="hidden"
                disabled={uploading}
                onChange={(event) => uploadLogo(event.target.files?.[0])}
              />
            </label>
          </Field>

          <Field label="Logo alignment">
            <select
              value={profile.logo_alignment}
              onChange={(event) =>
                updateField(
                  "logo_alignment",
                  event.target.value as BrandProfile["logo_alignment"],
                )
              }
              className="brand-input"
            >
              <option value="left">Left</option>
              <option value="center">Center</option>
              <option value="right">Right</option>
            </select>
          </Field>

          <ColorField
            label="Primary color"
            value={profile.primary_color}
            onChange={(value) => updateField("primary_color", value)}
          />

          <ColorField
            label="Secondary color"
            value={profile.secondary_color}
            onChange={(value) => updateField("secondary_color", value)}
          />

          <ColorField
            label="Accent color"
            value={profile.accent_color}
            onChange={(value) => updateField("accent_color", value)}
          />

          <Field label="Logo width">
            <input
              type="range"
              min="60"
              max="300"
              value={profile.logo_width}
              onChange={(event) =>
                updateField("logo_width", Number(event.target.value))
              }
              className="w-full"
            />
            <div className="mt-1 text-xs text-muted">
              {profile.logo_width}px
            </div>
          </Field>

          <Field label="Heading font">
            <select
              value={profile.heading_font}
              onChange={(event) =>
                updateField("heading_font", event.target.value)
              }
              className="brand-input"
            >
              <option value="Georgia">Georgia</option>
              <option value="Arial">Arial</option>
              <option value="Times New Roman">Times New Roman</option>
              <option value="Verdana">Verdana</option>
            </select>
          </Field>

          <Field label="Body font">
            <select
              value={profile.body_font}
              onChange={(event) =>
                updateField("body_font", event.target.value)
              }
              className="brand-input"
            >
              <option value="Arial">Arial</option>
              <option value="Georgia">Georgia</option>
              <option value="Verdana">Verdana</option>
              <option value="Times New Roman">Times New Roman</option>
            </select>
          </Field>

          <Field label="Email">
            <input
              value={profile.email}
              onChange={(event) => updateField("email", event.target.value)}
              className="brand-input"
              type="email"
            />
          </Field>

          <Field label="Phone">
            <input
              value={profile.phone}
              onChange={(event) => updateField("phone", event.target.value)}
              className="brand-input"
            />
          </Field>

          <Field label="Website">
            <input
              value={profile.website}
              onChange={(event) => updateField("website", event.target.value)}
              className="brand-input"
              placeholder="https://example.com"
            />
          </Field>

          <Field label="Business address">
            <textarea
              value={profile.address}
              onChange={(event) => updateField("address", event.target.value)}
              className="brand-input min-h-24"
            />
          </Field>

          <Field label="Document footer">
            <textarea
              value={profile.footer}
              onChange={(event) => updateField("footer", event.target.value)}
              className="brand-input min-h-24"
              placeholder="Phone · Email · Website"
            />
          </Field>

          <Field label="Legal disclaimer">
            <textarea
              value={profile.disclaimer}
              onChange={(event) =>
                updateField("disclaimer", event.target.value)
              }
              className="brand-input min-h-24"
            />
          </Field>

          <Field label="Watermark text">
            <input
              value={profile.watermark}
              onChange={(event) => updateField("watermark", event.target.value)}
              className="brand-input"
              placeholder="DRAFT or CONFIDENTIAL"
            />
          </Field>
        </div>
      </section>

      <aside className="rounded-2xl border border-line bg-paper p-4">
        <div className="mb-3 text-xs font-bold uppercase tracking-wide text-muted">
          Live document preview
        </div>

        <div
          className="relative min-h-[620px] overflow-hidden rounded-xl bg-white p-8 shadow-sm"
          style={{ fontFamily: profile.body_font }}
        >
          {profile.watermark && (
            <div className="pointer-events-none absolute inset-0 grid -rotate-45 place-items-center text-5xl font-bold opacity-[0.04]">
              {profile.watermark}
            </div>
          )}

          <div
            className={`flex ${
              profile.logo_alignment === "center"
                ? "justify-center"
                : profile.logo_alignment === "right"
                  ? "justify-end"
                  : "justify-start"
            }`}
          >
            {profile.logo_url ? (
              <img
                src={profile.logo_url}
                alt="Office logo"
                style={{
                  width: profile.logo_width,
                  maxHeight: 100,
                  objectFit: "contain",
                }}
              />
            ) : (
              <div className="grid h-20 w-40 place-items-center rounded-xl border border-dashed border-line text-muted">
                <ImagePlus size={24} />
              </div>
            )}
          </div>

          <div
            className="mt-6 h-1 rounded-full"
            style={{ backgroundColor: profile.primary_color }}
          />

          <h3
            className="mt-8 text-2xl font-bold"
            style={{
              fontFamily: profile.heading_font,
              color: profile.secondary_color,
            }}
          >
            Engagement Letter
          </h3>

          <p className="mt-5 text-sm leading-7 text-slate-700">Dear Client,</p>

          <p className="mt-3 text-sm leading-7 text-slate-700">
            Thank you for choosing <strong>{displayName}</strong>. This preview
            shows how your office branding will appear on generated documents.
          </p>

          <div
            className="mt-10 rounded-lg p-4 text-sm"
            style={{
              backgroundColor: `${profile.primary_color}12`,
              border: `1px solid ${profile.primary_color}35`,
            }}
          >
            Branded callouts and signature areas will use the colors selected
            for this workspace.
          </div>

          {profile.disclaimer && (
            <p className="mt-8 text-[10px] leading-5 text-muted">
              {profile.disclaimer}
            </p>
          )}

          <div className="absolute bottom-8 left-8 right-8 border-t pt-4 text-center text-[10px] text-muted">
            <div>{profile.footer || contactLine}</div>
            <div className="mt-1 whitespace-pre-line">{profile.address}</div>
            <div className="mt-2">Powered by VerexaHQ</div>
          </div>
        </div>
      </aside>

      <style jsx>{`
        .brand-input {
          width: 100%;
          border: 1px solid var(--line, #e5e7eb);
          border-radius: 0.75rem;
          padding: 0.7rem 0.8rem;
          font-size: 0.875rem;
          background: white;
          outline: none;
        }

        .brand-input:focus {
          border-color: #108a64;
          box-shadow: 0 0 0 3px rgba(16, 138, 100, 0.12);
        }
      `}</style>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-bold uppercase tracking-wide text-muted">
        {label}
      </span>
      {children}
    </label>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <Field label={label}>
      <div className="flex gap-2">
        <input
          type="color"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className="h-11 w-14 rounded-lg border border-line p-1"
        />
        <input
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className="brand-input"
        />
      </div>
    </Field>
  );
}
